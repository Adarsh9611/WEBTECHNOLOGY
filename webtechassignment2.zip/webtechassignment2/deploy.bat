@echo off
echo Preparing files for deployment...

echo Creating archive...
powershell Compress-Archive -Path index.html,styles.css,script.js,process.php,README.md -DestinationPath registration-form-app.zip -Force

echo Archive created: registration-form-app.zip
echo.
echo Deployment Instructions:
echo 1. Upload the zip file to your hosting provider
echo 2. Extract the files to your web directory
echo 3. Make sure your hosting provider supports PHP
echo 4. Access your site through your browser
echo.
echo For Heroku deployment:
echo 1. Unzip the file
echo 2. Follow the instructions in README.md
echo.
echo Deployment package ready!
pause