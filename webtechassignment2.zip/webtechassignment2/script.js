$(document).ready(function() {
    // Clear error messages when user starts typing
    $('input, select, textarea').on('input change', function() {
        const fieldName = $(this).attr('id');
        $('#' + fieldName + 'Error').text('');
    });

    // Form submission handler
    $('#registrationForm').on('submit', function(e) {
        // Prevent default form submission
        e.preventDefault();
        
        // Clear all previous error messages
        $('.error').text('');
        
        // Get form values
        const firstName = $('#firstName').val().trim();
        const lastName = $('#lastName').val().trim();
        const email = $('#email').val().trim();
        const phone = $('#phone').val().trim();
        const dob = $('#dob').val();
        const gender = $('#gender').val();
        const address = $('#address').val().trim();
        const course = $('#course').val();
        
        // Validation flag
        let isValid = true;
        
        // Validate First Name
        if (firstName === '') {
            $('#firstNameError').text('First name is required');
            isValid = false;
        } else if (firstName.length < 2) {
            $('#firstNameError').text('First name must be at least 2 characters');
            isValid = false;
        }
        
        // Validate Last Name
        if (lastName === '') {
            $('#lastNameError').text('Last name is required');
            isValid = false;
        } else if (lastName.length < 2) {
            $('#lastNameError').text('Last name must be at least 2 characters');
            isValid = false;
        }
        
        // Validate Email
        if (email === '') {
            $('#emailError').text('Email is required');
            isValid = false;
        } else if (!isValidEmail(email)) {
            $('#emailError').text('Please enter a valid email address');
            isValid = false;
        }
        
        // Validate Phone
        if (phone === '') {
            $('#phoneError').text('Phone number is required');
            isValid = false;
        } else if (!isValidPhone(phone)) {
            $('#phoneError').text('Please enter a valid phone number');
            isValid = false;
        }
        
        // Validate Date of Birth
        if (dob === '') {
            $('#dobError').text('Date of birth is required');
            isValid = false;
        } else {
            const dobDate = new Date(dob);
            const today = new Date();
            const minAgeDate = new Date();
            minAgeDate.setFullYear(today.getFullYear() - 15); // Minimum age of 15
            
            if (dobDate > today) {
                $('#dobError').text('Date of birth cannot be in the future');
                isValid = false;
            } else if (dobDate > minAgeDate) {
                $('#dobError').text('You must be at least 15 years old');
                isValid = false;
            }
        }
        
        // Validate Gender
        if (gender === '') {
            $('#genderError').text('Please select your gender');
            isValid = false;
        }
        
        // Validate Address
        if (address === '') {
            $('#addressError').text('Address is required');
            isValid = false;
        } else if (address.length < 10) {
            $('#addressError').text('Please enter a valid address');
            isValid = false;
        }
        
        // Validate Course
        if (course === '') {
            $('#courseError').text('Please select a course');
            isValid = false;
        }
        
        // If all validations pass, submit the form
        if (isValid) {
            // Show loading state
            const submitBtn = $('button[type="submit"]');
            const originalText = submitBtn.text();
            submitBtn.text('Processing...');
            submitBtn.prop('disabled', true);
            
            // Submit the form after a short delay to show loading state
            setTimeout(() => {
                $('#registrationForm')[0].submit();
            }, 1000);
        }
    });
    
    // Email validation function
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Phone validation function
    function isValidPhone(phone) {
        const phoneRegex = /^[0-9]{10,15}$/;
        return phoneRegex.test(phone.replace(/[\s()-]/g, ''));
    }
});