#!/bin/bash
# Simple deployment script for the registration form application

echo "Preparing files for deployment..."

# Create a zip file of all project files
echo "Creating archive..."
zip -r registration-form-app.zip index.html styles.css script.js process.php README.md

echo "Archive created: registration-form-app.zip"
echo ""
echo "Deployment Instructions:"
echo "1. Upload the zip file to your hosting provider"
echo "2. Extract the files to your web directory"
echo "3. Make sure your hosting provider supports PHP"
echo "4. Access your site through your browser"
echo ""
echo "For Heroku deployment:"
echo "1. Unzip the file"
echo "2. Follow the instructions in README.md"
echo ""
echo "Deployment package ready!"