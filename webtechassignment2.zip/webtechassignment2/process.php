<?php
// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and collect form data
    $firstName = htmlspecialchars(trim($_POST['firstName']));
    $lastName = htmlspecialchars(trim($_POST['lastName']));
    $email = htmlspecialchars(trim($_POST['email']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $dob = htmlspecialchars(trim($_POST['dob']));
    $gender = htmlspecialchars(trim($_POST['gender']));
    $address = htmlspecialchars(trim($_POST['address']));
    $course = htmlspecialchars(trim($_POST['course']));
    
    // Format date of birth
    $dobFormatted = date("F j, Y", strtotime($dob));
    
    // Map course value to display name
    $courses = [
        'web-development' => 'Web Development',
        'data-science' => 'Data Science',
        'mobile-apps' => 'Mobile App Development',
        'cybersecurity' => 'Cybersecurity',
        'ui-ux' => 'UI/UX Design'
    ];
    $courseName = isset($courses[$course]) ? $courses[$course] : $course;
    
    // Map gender value to display name
    $genders = [
        'male' => 'Male',
        'female' => 'Female',
        'other' => 'Other'
    ];
    $genderName = isset($genders[$gender]) ? $genders[$gender] : $gender;
    
    // Display the success page with user data
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registration Successful</title>
        <link rel="stylesheet" href="styles.css">
    </head>
    <body>
        <div class="container success-container">
            <h2>Registration Successful!</h2>
            <p>Thank you for registering with us. Here are your details:</p>
            
            <div class="user-details">
                <div class="detail-item">
                    <span class="detail-label">Full Name:</span>
                    <span class="detail-value"><?php echo $firstName . ' ' . $lastName; ?></span>
                </div>
                
                <div class="detail-item">
                    <span class="detail-label">Email:</span>
                    <span class="detail-value"><?php echo $email; ?></span>
                </div>
                
                <div class="detail-item">
                    <span class="detail-label">Phone:</span>
                    <span class="detail-value"><?php echo $phone; ?></span>
                </div>
                
                <div class="detail-item">
                    <span class="detail-label">Date of Birth:</span>
                    <span class="detail-value"><?php echo $dobFormatted; ?></span>
                </div>
                
                <div class="detail-item">
                    <span class="detail-label">Gender:</span>
                    <span class="detail-value"><?php echo $genderName; ?></span>
                </div>
                
                <div class="detail-item">
                    <span class="detail-label">Address:</span>
                    <span class="detail-value"><?php echo nl2br($address); ?></span>
                </div>
                
                <div class="detail-item">
                    <span class="detail-label">Course Interested In:</span>
                    <span class="detail-value"><?php echo $courseName; ?></span>
                </div>
            </div>
            
            <a href="index.html" class="back-link">← Back to Registration Form</a>
        </div>
    </body>
    </html>
    <?php
} else {
    // If someone tries to access this page directly without submitting the form
    header('Location: index.html');
    exit();
}
?>