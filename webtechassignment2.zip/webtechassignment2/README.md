# Online Registration Form Application

This is a web application built with HTML, CSS, JavaScript, jQuery, and PHP for online registration/application form submission.

## Features

- Responsive registration form with validation
- Client-side validation using JavaScript and jQuery
- Server-side processing with PHP
- Stylish UI with CSS gradients and animations
- Formatted display of submitted data

## Files Included

- `index.html` - Main registration form
- `styles.css` - Styling for the form and success page
- `script.js` - JavaScript/jQuery validation
- `process.php` - PHP script to handle form submission and display results

## Deployment Options

### Option 1: Heroku (Recommended)

1. Install the Heroku CLI from https://devcenter.heroku.com/articles/heroku-cli
2. Create a new Heroku app:
   ```
   heroku create your-app-name
   ```
3. Set the stack to container:
   ```
   heroku stack:set container
   ```
4. Create a `heroku.yml` file in the project root:
   ```yaml
   build:
     docker:
       web: Dockerfile
   run:
     web: vendor/bin/heroku-php-apache2
   ```
5. Create a `Dockerfile` in the project root:
   ```dockerfile
   FROM php:7.4-apache
   COPY . /var/www/html/
   ```
6. Deploy the app:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   heroku git:remote -a your-app-name
   git push heroku master
   ```

### Option 2: 000WebHost (Easiest)

1. Go to https://www.000webhost.com/
2. Sign up for a free account
3. Create a new website
4. Upload all files via the file manager
5. Your app will be live at the provided URL

### Option 3: InfinityFree

1. Go to https://infinityfree.net/
2. Register for a free account
3. Create a new hosting account
4. Upload all files via FTP or file manager
5. Access your site using the provided domain

## Requirements

- PHP 7.0 or higher
- Apache or Nginx web server

## Local Development

To run locally, you'll need to install a local server environment:

- Windows: Install XAMPP from https://www.apachefriends.org/index.html
- Mac: Install MAMP from https://www.mamp.info/en/
- Linux: Install LAMP stack

After installation:

1. Place all files in the web root directory (htdocs for XAMPP)
2. Start the Apache and MySQL services
3. Open your browser and navigate to http://localhost/your-folder-name/

## Support

For any issues, please check that all files are uploaded correctly and that your hosting provider supports PHP.
